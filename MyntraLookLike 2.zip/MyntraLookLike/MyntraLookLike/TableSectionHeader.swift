//
//  TableSectionHeader.swift
//  MyntraLookLike
//
//  Created by MAC on 16/02/17.
//  Copyright © 2017 Appinventiv. All rights reserved.
//

import UIKit

class TableSectionHeader: UITableViewHeaderFooterView {
    @IBOutlet weak var headerLabel: UILabel!
    

}
